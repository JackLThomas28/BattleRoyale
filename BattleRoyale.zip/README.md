Project for Spring CS5410 Game Development. 

A Battle Royale Game created by Bobby Handley and Jack Thomas.

Location for networking requirements:

server/game.js
client/game.js

The game begins once the lobby count down has finished. It can be changed
in server/game.js